﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CC_SpaceInvaders
{
    abstract class Sprite
    {
        public Sprite()
        {

        }

        public abstract void Paint(object sender, PaintEventArgs e);
    }
}
