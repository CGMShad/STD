﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CC_SpaceInvaders
{
    class Alien : Sprite
    {
        private PointF Location;
        private SizeF Size;
        public Alien(PointF location, SizeF size)
        {
            Location = location;
            Size = size;
        }
        public Alien() : this(new PointF(10, 10),new SizeF(20,20)) { }

        public override void Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(Properties.Resources.alien, new RectangleF(Location, new SizeF(20, 20)));
        }
    }
}
