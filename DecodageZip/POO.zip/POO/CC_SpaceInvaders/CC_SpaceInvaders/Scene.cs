﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CC_SpaceInvaders
{
    class Scene : Control
    {
        int score;
        int highscore;
        int lives;
        Bitmap bmp = null;
        Graphics g = null;


        public Scene() : base()
        {
            DoubleBuffered = true;
            Spaceship sc = new Spaceship();
            Paint += sc.Paint;
            for (int y = 0; y < 4; y++)
            {
                for (int i = 0; i < 10; i++)
                {
                    //Point x : his number * (his width + margin) 
                    //Poinzt y : his number * (his height + margin)
                    Alien al = new Alien(new PointF(i* (20 +5) , y * (20 + 5)),new SizeF(20,20));
                    Paint += al.Paint;
                }
            }
            
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            bmp ??= new Bitmap(Size.Width, Size.Height);
            g ??= Graphics.FromImage(bmp);

            PaintEventArgs p = new PaintEventArgs(g, e.ClipRectangle);

            g.Clear(BackColor);

            base.OnPaint(p);

            e.Graphics.DrawImage(bmp, new Point(0, 0));
        }
    }
}
