﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CC_SpaceInvaders
{
    class Spaceship : Sprite
    {
        private PointF Location;
        private SizeF Size;
        public Spaceship(PointF location, SizeF size)
        {
            Location = location;
            Size = size;
        }
        public Spaceship() : this(new PointF(100, 100),new SizeF(20,20)) { }

        public override void Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(Properties.Resources.spaceship, new RectangleF(Location, Size));
        }
    }
}
