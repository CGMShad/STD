﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CC_Control
{
    class Sprite
    {
        Stopwatch sw;

        private PointF startLocation;
        private PointF speed;
        private PointF Location
        {
            get
            {
                return new PointF(
                    (speed.X / 1000 * (float)sw.Elapsed.TotalMilliseconds) + startLocation.X,
                    (speed.Y / 1000 * (float)sw.Elapsed.TotalMilliseconds) + startLocation.Y
                );
            }
        }
        public Sprite(PointF aSpeed)
        {
            speed = aSpeed; //Number of pixels per seconds
            startLocation = new PointF(0,0);
            sw = new Stopwatch();
            sw.Start();
        }

        public void Paint(object sender, PaintEventArgs e)
        {

            e.Graphics.FillRectangle(Brushes.Blue, new RectangleF(Location, new SizeF(10, 10)));
        }
    }
}
