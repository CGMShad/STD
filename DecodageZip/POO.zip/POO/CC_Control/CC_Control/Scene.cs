﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CC_Control
{
    class Scene : Control
    {
        Bitmap bmp = null;
        Graphics g = null;
        Timer t;
        Random rdm;
        public Scene() : base()
        {
            rdm = new Random();
            t = new Timer();
            t.Interval = 1000/60; 
            t.Enabled = true;
            t.Tick += new EventHandler(OnTick);
            DoubleBuffered = true;
            for (int i = 0; i < 150; i++)
            {
                var sprite = new Sprite(new PointF(rdm.Next(100), rdm.Next(100)));
                Paint += sprite.Paint;
            }
        }

        private void OnTick(object sender, EventArgs e)
        {
            Invalidate(true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            bmp ??= new Bitmap(Size.Width, Size.Height);
            g ??= Graphics.FromImage(bmp);

            PaintEventArgs p = new PaintEventArgs(g, e.ClipRectangle);

            g.Clear(BackColor);
            g.FillRectangle(Brushes.Red, new Rectangle(10, 10, 20, 20));
            
            
            //Permet le chainage des différents paint. 
            base.OnPaint(p);

            e.Graphics.DrawImage(bmp, new Point(0, 0));
        }
    }

}
